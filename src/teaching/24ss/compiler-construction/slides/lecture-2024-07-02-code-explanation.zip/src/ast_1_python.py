from ast import TypeVar
from dataclasses import dataclass
from re import T
from typing import Literal

from identifier import Id
from util.immutable_list import IList


# Types

type Type = TInt | TBool | TVoid | TTuple | TCallable | TAll | TVar

@dataclass(frozen=True)
class TInt:
    pass

@dataclass(frozen=True)
class TBool:
    pass

@dataclass(frozen=True)
class TVoid:
    pass

@dataclass(frozen=True)
class TTuple:
    components: IList[Type]

@dataclass(frozen=True)
class TCallable:
    argtypes: IList[Type]
    restype: Type

@dataclass(frozen=True)
class TAll:
    tvars: IList[Id]
    tbody: Type

@dataclass(frozen=True)
class TVar:
    name: Id

# Unary Operators

type Op1 = Literal["-", "not"]

# Binary Operators

type Op2 = Literal["+", "-", "==", "!=", "<=", "<", ">", ">=", "and", "or", "is"]

# Expressions

type Expr = EConst | EVar | EOp1 | EOp2 | EInput | EIf | ETuple | \
    ETupleAccess | ETupleLen | ECall | ELambda | EArity

@dataclass
class ELambda:
    names: IList[Id]
    body: Expr

@dataclass
class EArity:
    exp: Expr

@dataclass(frozen=True)
class EConst:
    value: int | bool

@dataclass(frozen=True)
class EVar:
    name: Id

@dataclass(frozen=True)
class EOp1:
    op: Op1
    operand: Expr

@dataclass(frozen=True)
class EOp2:
    left: Expr
    op: Op2
    right: Expr

@dataclass(frozen=True)
class EInput:
    pass

@dataclass(frozen=True)
class EIf:
    test: Expr
    body: Expr
    orelse: Expr

@dataclass(frozen=True)
class ETuple:
    entries: IList[Expr]

@dataclass(frozen=True)
class ETupleAccess:
    e: Expr
    index: int

@dataclass(frozen=True)
class ETupleLen:
    e: Expr

@dataclass(frozen=True)
class ECall:
    func: Expr
    args: IList[Expr]

# Statements

type Stmt = SExpr | SPrint | SAssign | SIf | SWhile | SReturn | \
    SAnnAssign

@dataclass
class SAnnAssign:
    lhs: Id
    tyv: Type
    expr: Expr

@dataclass(frozen=True)
class SExpr:
    expr: Expr

@dataclass(frozen=True)
class SPrint:
    expr: Expr

@dataclass(frozen=True)
class SAssign:
    lhs: Id
    rhs: Expr

@dataclass(frozen=True)
class SIf:
    test: Expr
    body: IList[Stmt]
    orelse: IList[Stmt]

@dataclass(frozen=True)
class SWhile:
    test: Expr
    body: IList[Stmt]

@dataclass(frozen=True)
class SReturn:
    expr: Expr

# Function definitions

@dataclass(frozen=True)
class Definition:
    funcvar: Id
    ty_parameters: IList[Id]
    parameters: IList[tuple[Id, Type]]
    return_type: Type
    body: IList[Stmt]

# Programs

@dataclass(frozen=True)
class Program:
    defs: IList[Definition]
    body: IList[Stmt]

# Pretty Printing

def indent(s: str) -> str:
    return "\n".join(4 * " " + l for l in s.splitlines())

def pretty(p: Program) -> str:
    match p:
        case Program(defs, body):
            return "\n".join(pretty_def(d) for d in defs) + pretty_stmt_list(body)

def pretty_type(t: Type) -> str:
    match t:
        case TInt():
            return "int"
        case TBool():
            return "bool"
        case TVoid():
            return "void"
        case TTuple(ts):
            return f"tuple[{", ".join(pretty_type(t) for t in ts)}]"
        case TCallable(argtypes, result_type):
            return f"Callable[[{", ".join(pretty_type(t) for t in argtypes)}], {pretty_type(result_type)}]"
        case TAll(tvars, tbody):
            return f"All[[{", ".join(str(tv) for tv in tvars)}], {pretty_type(tbody)}]"
        case TVar(name):
            return str(name)

def pretty_parm(parm: tuple[Id, Type]) -> str:
    match parm:
        case (v, t):
            return f"{v}: {pretty_type(t)}"

def pretty_def(d: Definition) -> str:
    def p_tys(tvs: IList[Id]) -> str:
        if len(tvs) == 0:
            return ""
        return f"[{",".join(str(tv) for tv in tvs)}]"

    match d:
        case Definition(f, ty_parms, parms, ret, body):
            return \
                f"def {f}{p_tys(ty_parms)}({", ".join(pretty_parm(parm) for parm in parms)}) -> {pretty_type(ret)}:\n" + \
                indent(pretty_stmt_list(body))

def pretty_stmt_list(ss: IList[Stmt]) -> str:
    return "\n".join(pretty_stmt(s) for s in ss)

def pretty_stmt(s: Stmt) -> str:
    match s:
        case SExpr(e):
            return pretty_expr(e)
        case SAssign(x, e):
            return str(x) + " = " + pretty_expr(e)
        case SPrint(e):
            return "print(" + pretty_expr(e) + ")"
        case SIf(test, body, orelse):
            return f"if {pretty_expr(test)}:\n" \
                   f"{indent(pretty_stmt_list(body))}\n" \
                   f"else:\n" \
                   f"{indent(pretty_stmt_list(orelse))}"
        case SWhile(test, body):
            return f"while {pretty_expr(test)}:\n{indent(pretty_stmt_list(body))}"
        case SReturn(e):
            return f"return {pretty_expr(e)}"
        case SAnnAssign(x, t, e):
            return f"{x} : {pretty_type(t)} = {pretty_expr(e)}"

def pretty_expr(e: Expr) -> str:
    match e:
        case EConst(x) | EVar(x):
            return str(x)
        case EOp1(op, e):
            return f"{op} {pretty_expr(e)}"
        case EOp2(e1, op, e2):
            return f"({pretty_expr(e1)} {op} {pretty_expr(e2)})"
        case EInput():
            return "input_int()"
        case EIf(test, body, orelse):
            return f"({pretty_expr(body)} if {pretty_expr(test)} else {pretty_expr(orelse)})"
        case ETuple(entries):
            return "(" + ", ".join(pretty_expr(e) for e in entries) + ")"
        case ETupleAccess(e, i):
            return f"{pretty_expr(e)}[{i}]"
        case ETupleLen(e):
            return f"len({pretty_expr(e)})"
        case ECall(func, args):
            return f"{pretty_expr(func)}({", ".join(pretty_expr(e) for e in args)})"
        case ELambda(vars, body):
            return f"(lambda {", ".join(map(str, vars))}: {pretty_expr(body)})"
        case EArity(e):
            return f"arity({pretty_expr(e)})"
