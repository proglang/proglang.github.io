# A Language with Top-Level Functions and Lambda Expressions

We add lambda expressions and an `arity` expression to the source language and one new statement.
The new statement is annotated assignment `var : type = expr`.

## Representation of Function Objects

The representation of function objects remains the same as before.

* name of the function
* list of formal parameters
* function body (list of statements)
* runtime environment

The interpretation of the lambda expression and the arity function is straightforward:

```python
        case ELambda(xs, expr):
            return VFunction(Id("lambda"), xs, ilist(SReturn(expr)), env)
        case EArity(expr):
            v = eval_expr(env, expr)
            match v:
                case VFunction(_, xs, _, _):
                    return len(xs)
                case _:
                    raise Exception(f"Tried to take arity of non function {pretty_expr(expr)}")
```

The interpretation of the annotated assignment is like the regular assignment, but ignores the type annotation.

## Revised Runtime Environments

The previous definition of runtime environments does not work anymore.
The problem lies in this part of `apply_fun`:

```python
        case VFunction(name, parms, body, env):
            fenv = env.copy()
            fenv.update(zip(parms, xs))
            return eval_list_stmt(fenv, body)
```

That is, the function call freezes the environment `env` (as we copy it).
If someone performs an assignment to a free variable, this change in `env` is no longer visible to the function. For example:

```python
x = 41
f = lambda : x
x = x+1
print( f() ) # prints 42
```

```python
x = 41
f = lambda g : g() == x
def g():
    global x
    x = x + 1
    return x
```

Running it reveals that the change that `g` performs on `x` is visible in `f`:

```python
>>> x
41
>>> f(g)
True
>>> x
42
```

We address this issue with a revised environment structure.
The runtime environment is essentially a list of dictionaries.
Each dictionary represents a scope. The first dictionary represents the innermost scope,
then the surrounding scopes, and finally the top-level scope (global scope).
Often these environments are called *ribs*.

```python
@dataclass(frozen=True)
class RTEnv:
    current: dict[Id, Value]
    parent: Optional['RTEnv']

def lookup(cur: Optional[RTEnv], x: Id) -> Value:
    while cur is not None and x not in cur.current.keys():
        cur = cur.parent
    if cur is None:
        raise Exception(f"Identifier not found {x}")
    else:
        return cur.current[x]

def assign(env: RTEnv, x: Id, v: Value):
    env.current[x] = v
```

This representation is called *nested closures*.
The nesting represents the nesting of scopes. 
It is easy to adapt to full nested function definitions.

To use this representation, we have to replace dictionary accesses by `lookup` and provide an `assign` function that performs the assignment on the outermost rib.
(If we were to support Pythons's `nonlocal` and `global` declarations, the `assign` function would become more complex.)

## Interpretation with Nested Closures

With nested closures, function application gets a little simpler, because no copying is needed:

* the definition environment of the closure becomes the parent
* the new rib for the callee's environment is a freshly created dictionary

```python
def apply_fun(f: Value, xs: tuple[Value, ...]) -> Optional[Value]:
    match f:
        case VFunction(_, parms, body, env):
            fenv = RTEnv(dict(zip(parms, xs)), env)
            return eval_list_stmt(fenv, body)
        case _:
            raise Exception('apply_fun: unexpected value ' + repr(f))
```

Closure creation just captures the current environment.

```python
        case ELambda(xs, expr):
            return VFunction(Id("lambda"), xs, ilist(SReturn(expr)), env)
```

At the beginning, we initialize the runtime environment appropriately:

* the current environment starts out empty
* there is no parent environment

```python
def eval_prog(p: Program):
    match p:
        case Program(defs, body):
            env: RTEnv = RTEnv(dict(), None)
            eval_list_defs(env, defs)
            eval_list_stmt(env, body)
```

## Type Checking

When using a `lambda`, we require an annotated assignment to keep the type checking simple.
Example:
```
f : Callable[[int], int] = lambda x: x+1
```

To this end, we extend `type_check_expr` to flag unanotated uses of `lambda`:

```python
        case ELambda():
            raise TypeError(f"Cannot synthesize type of {pretty_expr(e)}")
        case EArity(e):
            te = type_check_expr(ctx, e)
            match te:
                case TCallable():
                    return TInt()
                case _:
                    raise TypeError(f"Arity expects a function in {pretty_expr(e)}")
```

Instead we provide a function `check_expr` that checks an expression against a given type.
Here we use it to type check the annotated assignment:

```python
        case SAnnAssign(x, t, e):
            if x in ctx:
                check_type_equal(t, ctx[x], s)
            else:
                ctx[x] = t
            check_expr(ctx, e, t)
            return False
```

Here is the implementation. 
For a lambda the checking type has to be a function type.
Then we check the body by assuming the argument types and recursively checking the 
function body against the return type (remember that the body of the lambda may be another lambda).
For any other expression, we use the regular `type_check_expr` to *synthesize* the its type and compare it with the expected type.

```python
def check_expr(ctx: TCtx, e: Expr, ty: Type):
    match e:
        case ELambda(xs, body):
            match ty:
                case TCallable(arg_tys, ret_ty):
                    if len(xs) != len(arg_tys):
                        raise TypeError(f"Wrong number of arguments: {pretty_expr(e)} - {pretty_type(ty)}")
                    new_ctx = ctx.copy()
                    new_ctx.update(zip(xs, arg_tys))
                    check_expr(new_ctx, body, ret_ty)
                case _:
                    raise TypeError(f"Lambda cannot have type {pretty_type(ty)}")
        case _:
            te = type_check_expr(ctx, e)
            check_type_equal(te, ty, e)
```

## Flat Closures

The compiler could use nested closures, too, but their implementation is complex in full generality. 
Moreover, variable accesses may require chasing pointers along the spine of the environment (i.e., a function like `lookup` would have to be implemented).
Therefore, our implementation relies on *flat closures* where all free variables of a lambda are collected into one (flat) tuple.

This representation is at odds with the sharing semantics that we discussed in the context of nested closures. 
The solution is to introduce a level of indirection in a pass called *assignment conversion*.
For each variable that is assigned to (after initialization) we introduce an indirection in the form of a tuple.
Reading from the variable is converted to a tuple access and writing is converted to an update. 
With this variable representation, we can copy/share the pointer to the tuple freely and everyone can see all updates to the tuple.
(We could play the same game in the interpreter to avoid nested closures!)

## why do we need closures and assignment conversion?

```python
def f():
    x = 0
    g = lambda : x
    h = lambda : x
    x = 42
    return (g, h)
```

We need to apply assignment conversion to `x`.


```python
def f():
    x = (0,)
    g = lambda : x[0]
    h = lambda : x[0]
    x[0] = 42
    return (g, h)
```

The closures for g and h both contain pointers to `x`.

      g |-> | addr(lambda1) | x |
      h |-> | addr(lambda2) | x |

These are different heap tuples, but any assignment to `x` must be visible in both.
SO we need the additional indirection through the tuple `x`.