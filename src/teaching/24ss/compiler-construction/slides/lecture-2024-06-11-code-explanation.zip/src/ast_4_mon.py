from dataclasses import dataclass
from ssl import SSLZeroReturnError
from typing import Literal

# f(v[0]), f(v[1])
# -->
# x0 = v[0]
# x1 = f(x0)
# ----------
# x2 = v[1]
# x3 = f(x2)
# x5 = (x1,x3)

from identifier import Id
from util.immutable_list import IList

# Unary Operators

type Op1 = Literal["-", "not"]

# Binary Operators

type Op2Arith = Literal["+", "-"]
type Op2Comp = Literal["==", "!=", "<=", "<", ">", ">="]

# Atomic Expressions

type ExprAtom = EConst | EVar

@dataclass(frozen=True)
class EConst:
    value: int | bool
    size: Literal['64bit', '63bit']

@dataclass(frozen=True)
class EVar:
    name: Id

# Complex Expressions

type Expr = ExprAtom | EOp1 | EOp2Arith | EOp2Comp | EInput | ETupleAccess | ETupleLen \
          | EAllocate | EGlobal | ECall

@dataclass(frozen=True)
class EOp1:
    op: Op1
    operand: ExprAtom

@dataclass(frozen=True)
class EOp2Arith:
    left: ExprAtom
    op: Op2Arith
    right: ExprAtom

@dataclass(frozen=True)
class EInput:
    pass

@dataclass(frozen=True)
class EOp2Comp:
    left: ExprAtom
    cmp: Op2Comp
    right: ExprAtom

@dataclass(frozen=True)
class ETupleAccess:
    e: ExprAtom
    index: int

@dataclass(frozen=True)
class ETupleLen:
    e: ExprAtom

@dataclass(frozen=True)
class EAllocate:
    num_elems: int

type Global = Literal['gc_free_ptr', 'gc_fromspace_end']

@dataclass(frozen=True)
class EGlobal:
    var: Global

@dataclass(frozen=True)
class ECall:
    func: ExprAtom
    args: IList[ExprAtom]

# Left-hand sides of Assign Statements

type Lhs = LId | LSubscript

@dataclass
class LId:
    id: Id

@dataclass
class LSubscript:
    e: ExprAtom
    offset: int

# Statements

type Stmt = SPrint | SAssign | SIf | SWhile | SCollect | SReturn

@dataclass(frozen=True)
class SPrint:
    expr: ExprAtom

@dataclass(frozen=True)
class SAssign:
    lhs: Lhs
    rhs: Expr

@dataclass(frozen=True)
class SIf:
    test: EOp2Comp
    body: IList[Stmt]
    orelse: IList[Stmt]

@dataclass(frozen=True)
class SWhile:
    test_body: IList[Stmt]
    test_expr: EOp2Comp
    loop_body: IList[Stmt]

@dataclass(frozen=True)
class SCollect:
    num_bytes: int

@dataclass(frozen=True)
class SReturn:
    ret_expr: ExprAtom
# Types

type Types = TInt | TBool | TVoid | TTuple | TCallable

@dataclass(frozen=True)
class TInt:
    pass

@dataclass(frozen=True)
class TBool:
    pass

@dataclass(frozen=True)
class TVoid:
    pass

@dataclass(frozen=True)
class TTuple:
    components: IList[Types]

@dataclass(frozen=True)
class TCallable:
    argtypes: IList[Types]
    restype: Types

# Function definitions

@dataclass(frozen=True)
class Definition:
    funcvar: Id
    parameters: IList[tuple[Id, Types]]
    return_type: Types
    body: IList[Stmt]

# Programs

@dataclass(frozen=True)
class Program:
    defs: IList[Definition]
    body: IList[Stmt]

# Pretty Printing

def indent(s: str) -> str:
    return "\n".join(4 * " " + l for l in s.splitlines())

def pretty(p: Program) -> str:
    match p:
        case Program(defs, body):
            return "\n".join(pretty_def(d) for d in defs) + pretty_stmt_list(body)

def pretty_type(t: Types) -> str:
    match t:
        case TInt():
            return "int"
        case TBool():
            return "bool"
        case TVoid():
            return "void"
        case TTuple(ts):
            return f"tuple[{", ".join(pretty_type(t) for t in ts)}]"
        case TCallable(argtypes, result_type):
            return f"Callable[[{", ".join(pretty_type(t) for t in argtypes)}], {pretty_type(result_type)}]"

def pretty_parm(parm: tuple[Id, Types]) -> str:
    match parm:
        case (v, t):
            return f"{v}: {pretty_type(t)}"

def pretty_def(d: Definition) -> str:
    match d:
        case Definition(f, parms, ret, body):
            return \
                f"def {f}({", ".join(pretty_parm(parm) for parm in parms)}) -> {pretty_type(ret)}:\n" + \
                indent(pretty_stmt_list(body))

def pretty_stmt_list(ss: IList[Stmt]) -> str:
    return "\n".join(pretty_stmt(s) for s in ss)

def pretty_stmt(s: Stmt) -> str:
    match s:
        case SAssign(lhs, e):
            return pretty_lhs(lhs) + " = " + pretty_expr(e)
        case SPrint(e):
            return "print(" + pretty_expr(e) + ")"
        case SIf(test, body, orelse):
            return f"if {pretty_expr(test)}:\n" \
                   f"{indent(pretty_stmt_list(body))}\n" \
                   f"else:\n" \
                   f"{indent(pretty_stmt_list(orelse))}"
        case SWhile(test_body, test_expr, loop_body):
            if len(test_body) > 0:
                test_body_str = "".join(pretty_stmt(s) + "\n" for s in test_body)
                return (
                    "while {\n" +
                    indent(test_body_str + pretty_expr(test_expr)) + "\n" +
                    "}:\n" +
                    indent(pretty_stmt_list(loop_body))
                )
            else:
                return (
                    "while { " + pretty_expr(test_expr) + " }:\n" +
                    indent(pretty_stmt_list(loop_body))
                )
        case SCollect(num_words):
            return f"collect({num_words})"
        case SReturn(ret_expr):
            return f"return({pretty_expr(ret_expr)})"

def pretty_lhs(lhs: Lhs) -> str:
    match lhs:
        case LId(x):
            return str(x)
        case LSubscript(e, i):
            return f"{pretty_expr(e)}[{i}]"

def pretty_expr(e: Expr) -> str:
    match e:
        case EVar(x):
            return str(x)
        case EConst(x, size):
            return str(x) + ("" if size == "64bit" else "°")
        case EOp1(op, e):
            return f"{op} {pretty_expr(e)}"
        case EOp2Arith(e1, op, e2) | EOp2Comp(e1, op, e2):
            return f"({pretty_expr(e1)} {op} {pretty_expr(e2)})"
        case EInput():
            return "input_int()"
        case ETupleAccess(e, i):
            return f"{pretty_expr(e)}[{i}]"
        case ETupleLen(e):
            return f"len({pretty_expr(e)})"
        case EGlobal(g):
            return "@" + g
        case EAllocate(n):
            return f"allocate({n})"
        case ETupleAccess(e, i):
            return f"{pretty_expr(e)}[{i}]"
        case ETupleLen(e):
            return f"len({pretty_expr(e)})"
        case ECall(f, es):
            return f"{pretty_expr(f)}({", ".join(pretty_expr(e) for e in es)})"
