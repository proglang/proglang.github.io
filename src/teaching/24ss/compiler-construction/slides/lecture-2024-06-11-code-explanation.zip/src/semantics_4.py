from dataclasses import dataclass
from operator import call
from resource import RLIMIT_STACK
from typing import Optional

from ast_4_mon import *
from util.immutable_list import IList, ilist

# Simulate Integer Overflow Behavior

MAX_INT_63 = 2**62 - 1
MIN_INT_63 = -(2**62)

def simulate_over_and_underflow(i: int) -> int:
    while i > MAX_INT_63:
        i = i - (2**63)
    while i < MIN_INT_63:
        i = i + (2**63)
    return i

# Values

type Value = int | bool | VTuple | VFunction

# Value Environment

type RTEnv = dict[Id, Value]

@dataclass
class VTuple:
    entries: list[Value]

@dataclass
class VFunction:
    name: Id
    xs: IList[Id]
    body: IList[Stmt]
    env: RTEnv

@dataclass(frozen=True)
class VCont:
    target: Id
    env: RTEnv
    body: IList[Stmt]

type RTStack = list[VCont]

# Evaluation

def eval_expr(env: RTEnv, e: Expr) -> Value:
    match e:
        case EConst(c):
            return c
        case EVar(x):
            return env[x]
        case EOp1(op, e):
            v = eval_expr(env, e)
            match v:
                case VTuple(_) | VFunction():
                    raise Exception("Unary operator not allowed on tuple or function.")
                case _:
                    match op:
                        case "-":
                            return -v
                        case "not":
                            return not v
        case EOp2Arith(e1, op, e2) | EOp2Comp(e1, op, e2):
            v1 = eval_expr(env, e1)
            v2 = eval_expr(env, e2)
            match v1, v2:
                case (int(x1) | bool(x1)), (int(x2) | bool(x2)):
                    match op:
                        case "+":
                            return simulate_over_and_underflow(x1 + x2)
                        case "-":
                            return simulate_over_and_underflow(x1 - x2)
                        case "==":
                            return x1 == x2
                        case "!=":
                            return x1 != x2
                        case "<=":
                            return x1 <= x2
                        case "<":
                            return x1 < x2
                        case ">":
                            return x1 > x2
                        case ">=":
                            return x1 >= x2
                        case _:
                            raise Exception("Impossible!")
                case VTuple(_), VTuple(_):
                    match op:
                        case "is":
                            return v1 == v2
                        case _:
                            raise Exception("Impossible!")
                case _:
                    raise Exception("Binary operator not allowed on these operands.")
        case EInput():
            while True:
                try:
                    res = int(input())
                    return simulate_over_and_underflow(res)
                except ValueError:
                    continue
        case EAllocate(n):
            return VTuple([0 for e in range(n)])
        case ETupleAccess(e, i):
            match eval_expr(env, e):
                case VTuple(vs):
                    return vs[i]
                case _:
                    raise Exception("Tried to index into a non-tuple value.")
        case ETupleLen(e):
            match eval_expr(env, e):
                case VTuple(vs):
                    return len(vs)
                case _:
                    raise Exception("Tried to get length of non-tuple value.")
        case _:
            raise Exception("Unreachable")

def eval_list_stmt(stack: RTStack, env: RTEnv, ss: IList[Stmt]):
    while len(ss) > 0:
        ins = ss[0]
        ss = ss[1:]
        match ins:
            case SAssign(Id() as y, ECall(f, xs)):
                fv = eval_expr(env, f)
                xvs = tuple(eval_expr(env, x) for x in xs)
                match fv:
                    case VFunction(_, parms, body, fenv):
                        fun_env = fenv.copy()
                        fun_env.update(zip(parms, xvs))
                        cont = VCont(y, env, ss)
                        stack = [cont] + stack
                        env = fun_env
                        ss = body

            case SReturn(e):
                rv = eval_expr(env, e)
                if len(stack) == 0: raise Exception('RTStck underflow')
                match stack[0]:
                    case VCont(y, caller_env, body):
                        stack = stack[1:]
                        caller_env[y] = rv
                        ss = body
                        env = caller_env
            case SIf(test, body, orelse):
                if eval_expr(env, test):
                    ss = body + ss
                else:
                    ss = orelse + ss

            case SWhile(test_body, test_expr, body):
                ss = test_body + ilist(SIf(test_expr, body + ilist(ins), ilist())) + ss

            case SAssign(LId(x), e):
                env[x] = eval_expr(env, e)
            case SAssign(LSubscript(e0, offset), e1):
                v0 = eval_expr(env, e0)
                v1 = eval_expr(env, e1)
                match v0:
                    case VTuple(vt):
                        vt[offset] = v1
            case SPrint(e):
                print(eval_expr(env, e))
            case SCollect():
                pass


def eval_list_defs(env: RTEnv, defs: IList[Definition]):
    for d in defs:
        match d:
            case Definition(f, parms, ret, body):
                fv = VFunction(f, ilist(*[x for (x,t) in parms]), body, env)

def eval_prog(p: Program):
    match p:
        case Program(defs, body):
            env: RTEnv = dict()
            eval_list_defs(env, defs)
            stack: RTStack = []
            eval_list_stmt(stack, env, body)
