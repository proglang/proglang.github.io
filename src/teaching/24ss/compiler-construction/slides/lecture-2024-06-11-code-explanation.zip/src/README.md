# A Language with Top-Level Functions and Function Pointers

We add one new kind of expression to the source language and one new statement.
The new expression is a function call of the form `exp(exp, ..., exp)` and the new statement is `return exp`.
We also add function definitions with this abstract syntax:
```python
@dataclass(frozen=True)
class Definition:
    funcvar: Id
    parameters: IList[tuple[Id, Types]]
    return_type: Types
    body: IList[Stmt]
```
The formal parameters are represented as a list of pairs of identifiers and types.

## The Simple Interpreter

For the simple interpreter, we add a new kind of value that represents a function:
```python
@dataclass
class VFunction:
    name: Id            # name of the function
    formals: IList[Id]  # list of formal parameters
    body: IList[Stmt]   # function body
    env: RTEnv
```
The `env` component contains (currently and mainly) the bindings of all top-level functions.
This setup enables mutually recursive top-level functions, if we process the list of function defintions like this:
```python
def eval_list_defs(env: RTEnv, defs: IList[Definition]):
    for d in defs:
        match d:
            case Definition(f, parms, ret, body):
                fv = VFunction(f, IList([x for (x,t) in parms]), body, env)
                env[f] = fv
```
The interpretation of a function call proceeds by evaluating the function expression, the list of arguments, and then invoking the function `apply_fun`:
```python
def apply_fun(f: Value, xs: tuple[Value, ...]) -> Optional[Value]:
    match f:
        case VFunction(name, parms, body, env):
            fenv = env.copy()
            fenv.update(zip(parms, xs))
            return eval_list_stmt(fenv, body)
        case _:
            raise Exception('apply_fun: unexpected value ' + repr(f))
```
This function implements the core part of a function call. 
It unpacks the function value, extends its definition environment `env` with the new bindings of the formal parameters to the arguments, and then starts the function's body in this environment.

The interpretation of the `return exp` statement just evaluates the expression and returns.
```python
def eval_list_stmt(env: RTEnv, ss: IList[Stmt]) -> Optional[Value]:
    for s in ss:
        match s:
             ...
             case SReturn(e):
                return eval_expr(env, e)
```

## The Low-Level Interpreter

The previous implementation interprets function calls in the object language by function calls in the interpreter. That has two consequences.

1. The previous interpreter inherits the limitation on the depth of recursive function calls that Python imposes. To interpret a single function call requires three or more function calls in the interpreter.
2. The previous interpreter provides insights on the handling of the environments, but it does not explain how function call and return are managed because this is left to the implementation of Python.

To this end, we need a couple of steps.

### Transform to monadic style

We do this transformation anyway as part of the compilation pipeline.
Why do we need this transformation?
Consider this example:
```python
f(v[0]), f(v[1])
```
It contains two function calls. 
When we start the first function call, we need to remember that we still have to perform the rest of the computation, that is:
```python
_, f(v[1])
```
where the `_` indicates the position where we have to put the value of `f(v[0])` once it becomes available. Representing this structure explicitly is tricky, but it is simpler in monadic form. Here is the example code after transformation:
```python
x0 = v[0]
x1 = f(x0)
----------
x2 = v[1]
x3 = f(x2)
x5 = (x1,x3)
```
Now, the line indicates the place where we need to resume the computation, i.e., the list of instructions after the line. 
Next, we need the environment calculated up to the assignment to `x1` as it reflects the results of the computation up to the function calls.
Finally, we need the name `x1`, the variable where we have to store the return value of the function call.

### Introducing Continuations

Taking all that together, we can define a data structure that represents a (so-called) continuation:
```python
@dataclass(frozen=True)
class VCont:
    target: Id
    env: RTEnv
    body: IList[Stmt]
```
With that definition, we can run the whole program inside mildly nested function calls to `eval_list_stmt`. The price is that we introduce a stack of `VCont`, which implements a stack of activation records, just like we do in assembly language.
```python
def eval_list_stmt(env: RTEnv, ss: IList[Stmt]):
    stack: RTStack = []
    while len(ss) > 0:
        ins = ss[0]
        ss = ss[1:]
        match ins:
            case SAssign(Id() as y, ECall(f, xs)):
                fv = eval_expr(env, f)
                xvs = tuple(eval_expr(env, x) for x in xs)
                match fv:
                    case VFunction(_, parms, body, fenv):
                        fun_env = fenv.copy()
                        fun_env.update(zip(parms, xvs))
                        cont = VCont(y, env, ss)
                        stack = [cont] + stack        # push continuation
                        env = fun_env                 # install env for function body
                        ss = body                     # "jump" to function body

            case SReturn(e):
                rv = eval_expr(env, e)
                if len(stack) == 0: raise Exception('RTStck underflow')
                match stack[0]:
                    case VCont(y, caller_env, cont_ss):
                        stack = stack[1:]             # pop continuation
                        caller_env[y] = rv            # store return value in caller's env
                        env = caller_env              # install caller's env
                        ss = cont_ss                  # "jump" to return address
```
To call a function, we perform the same environment manipulation as before, then we create a new continuation `VCont(y, env, ss)` from the variable on the left hand side of the assignment, the current environment, and the list of statements following the function call.
Then we push the continuation on the stack, install the environment `fun_env` for the function body, and set the instruction list to the body.

To return from a function call, the runtime stack must be non-empty.
If so, we grab the top-level continuation (i.e., the top-level stack frame), pop the stack, store the return value in the caller's env (in variable 'y'), restore the caller's environment, and jump to the return address stored in the continuation.

### Conditionals by Program Transformation

For conditionals we cannot invoke `eval_list_stmt` recursively because a `return` nested in a then-branch or else-branch would not be handled correctly. Instead, we implement the conditional by transforming the continuation. 
If the condition is true, we prepend the then-branch to the continuation, otherwise the else-branch.
```python
            case SIf(test, body, orelse):
                if eval_expr(env, test):
                    ss = body + ss
                else:
                    ss = orelse + ss
```
To process the while-statement similarly, we can apply the defining equation of `while`:
```
    while b:
        body
##  --->
    if b:
        body
        while b:
            body
```
This rule can also be implemented in a straightforward rewrite of the instruction list.
There is a small complication because the test is split into a list of statements leading up to the test expression (a comparison).
```python
            case SWhile(test_body, test_expr, body):
                ss = test_body + ilist(SIf(test_expr, body + ilist(ins), ilist())) + ss
```


