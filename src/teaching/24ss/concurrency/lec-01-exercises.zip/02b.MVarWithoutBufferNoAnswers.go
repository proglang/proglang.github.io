package main

import "fmt"
import "time"

type MVar (chan int)

func newMVar(x int) MVar {
	var ch = make(chan int)
	go func() { ch <- x }()
	return ch
}

/*
The trick is:
* We create a synchronous channel `ch`.
* In a concurrent helper thread we fill the channel with an initial element.
  The helper thread blocks, but this way we guarantee the the MVar is initially filled.
* Since the blocking only happens in the concurrent helper thread, the channel `ch` can be returned as value.
Further MVar primitives can be built directly on the send/receive channel operations.
*/

func takeMVar(m MVar) int {
	var x int
	x = <- m
	return x
}

func putMVar(m MVar, x int) {
	go func() { m <- x }()
}

func producer(m MVar) {
	var x int = 1
	for {
		time.Sleep(1 * 1e9)
		putMVar(m, x)
		x++
	}
}

func consumer(m MVar) {
	for {
		var x int = takeMVar(m)
		fmt.Printf("Received %d \n", x)
	}
}

func testMVar() {
	var m MVar
	m = newMVar(1)
	go producer(m)
	consumer(m)
}

/*
Consider the following example.
What can go wrong?
*/

func testMVar2() {
	m := newMVar(1)
	go putMVar(m, 2)
	x := takeMVar(m)
	fmt.Printf("Received %d \n", x)
}

/*
A problem occurs when `takeMVar` and `putMVar` are executed consecutively.
Consider:
*/

func testMVar3() {
	var m MVar
	m = newMVar(1) // Full
	takeMVar(m)    // Empty
	putMVar(m, 2)  // Full
}

/*
According to the description of MVar, the above program should run, but it gets stuck.
Why?
How can we solve this?
*/

func main() {
	testMVar()
	// for {
	// 	testMVar2()
	// }
	// testMVar3() // deadlock
}