package main

import "fmt"
import "time"

type MVar (chan int)

func newMVar(x int) MVar {
	var ch = make(chan int, 1)
	ch <- x
	return ch
}

func takeMVar(m MVar) int {
	var x int
	x = <- m
	return x
}

func putMVar(m MVar, x int) {
	m <- x
}

func producer(m MVar) {
	var x int = 1
	for {
		time.Sleep(1 * 1e9)
		putMVar(m, x)
		x++
	}
}

func consumer(m MVar) {
	for {
		var x int = takeMVar(m)
		fmt.Printf("Received %d \n", x)
	}
}

func testMVar() {
	var m MVar
	m = newMVar(1)
	go producer(m)
	consumer(m)
}

func testMVar2() {
	m := newMVar(1) // 1
	go putMVar(m, 2) // 2
	time.Sleep(1e9)
	x := takeMVar(m)
	// if x == 1 {
		fmt.Printf("Received %d \n", x)
	// }
}

func testMVar3() {
	var m MVar
	m = newMVar(1) // Full
	takeMVar(m)    // Empty
	putMVar(m, 2)  // Full
}

func main() {
	// testMVar()
	// for {
	// 	testMVar2()
	// } // data race
	testMVar3()
}