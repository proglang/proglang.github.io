/*
An implementation of a mutex using a channel with buffer size 1.
*/
package main

import "fmt"
import "time"

type Mutex (chan int)

func newMutex() Mutex {
	var ch = make(chan int, 1)
	return ch
}

func lock(m Mutex) {
	m <- 1
}

func unlock(m Mutex) {
	<- m
}

var x int

func mySharedVar(y int, m Mutex) {
	for {
		lock(m)
		x = y
		time.Sleep(1e6) // 1ms
		fmt.Printf("%d=%d\n",x,y)
		unlock(m)
	}
}

func testMutex() {
	var m Mutex
	m = newMutex()

	go mySharedVar(1, m)
	mySharedVar(2, m)	
}

func main() {
	testMutex()
}