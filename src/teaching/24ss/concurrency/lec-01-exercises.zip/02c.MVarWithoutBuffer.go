package main

import "fmt"
import "time"

type MVar (chan int)

func newMVar(x int) MVar {
	var ch = make(chan int)
	go func() { ch <- x }()
	return ch
}

/*
The trick is:
* We create a synchronous channel `ch`.
* In a concurrent helper thread we fill the channel with an initial element.
  The helper thread blocks, but this way we guarantee the the MVar is initially filled.
* Since the blocking only happens in the concurrent helper thread, the channel `ch` can be returned as value.
Further MVar primitives can be built directly on the send/receive channel operations.
*/

func takeMVar(m MVar) int {
	var x int
	x = <- m
	return x
}

func putMVar(m MVar, x int) {
	m <- x
}

func producer(m MVar) {
	var x int = 1
	for {
		time.Sleep(1 * 1e9)
		putMVar(m, x)
		x++
	}
}

func consumer(m MVar) {
	for {
		var x int = takeMVar(m)
		fmt.Printf("Received %d \n", x)
	}
}

func testMVar() {
	var m MVar
	m = newMVar(1)
	go producer(m)
	consumer(m)
}

/*
If `newMVar` is directly followed by `putMVar`, it's possible that the send of `newMVar` is overtaken by the send of `putMVar`.
Consider the following example:
*/

func testMVar2() {
	m := newMVar(1) // 1
	go putMVar(m, 2) // 2
	x := takeMVar(m)
	fmt.Printf("Received %d \n", x)
}

/*
MVar is initially filled with `1`, but then by `2`.
Hence, we expect to print `2`.
However, it's quite possible that we print `1`.
*/

/* ## Problem: communication gets stuck.
A problem occurs when `takeMVar` and `putMVar` are executed consecutively.
Consider:
*/

func testMVar3() {
	var m MVar
	m = newMVar(1) // Full
	takeMVar(m)    // Empty
	putMVar(m, 2)  // Full
}

/*
According to the description of MVar, the above program should run, but it gets stuck.
Why?
* The initial filling of the MVar in `newMVar` happens asynchronously.
* All further `putMVar` operations are synchronous!
* Hence, `putMVar(m,2)` blocks, leading to a deadlock.
A solution: a concurrent thread that checks the state of the MVar:
*/

const (
	Empty = 0
	Full  = 1
)

func newMVar2(x int) MVar {
	var ch = make(chan int)
	go func() {
		for {
			ch <- x
			x = <- ch
		}
		// var state = Full
		// var elem int = x
		// for {
		// 	switch {
		// 	case state == Full:
		// 		ch <- elem
		// 		state = Empty
		// 	case state == Empty:
		// 		elem = <-ch
		// 		state = Full
		// 	}
		// }
	}()
	return ch
}

/*
`takeMVar` and `putMVar` are as before.
With this, the problem that communication gets stuck is fixed.
Consider:
* `takeMVar` and `putMVar` can also synchronise directly with each other, without synchronisation through the concurrent thread of `newMVar`.
* In such cases, of course the state of the MVar (correctly) stays the same.
* Nonetheless, direct communication is still a problem.
*/

// We use `newMVar2` instead of `newMVar`.
func testMVar4() {
	m := newMVar2(1) // 1
	go putMVar(m, 2) // 2
	x := takeMVar(m)
	// if x == 1 {
		fmt.Printf("Received %d \n", x)
	// }
}

func testMVar5() {
	var m MVar
	m = newMVar2(1) // Full
	takeMVar(m)     // Empty
	putMVar(m, 2)   // Full
}

func main() {
	testMVar()
	// for {
	// 	testMVar2()
	// } // data race
	// testMVar3() // deadlock
	// for {
	// 	testMVar4()
	// } // still a data race
	// testMVar5() // no deadlock anymore
}