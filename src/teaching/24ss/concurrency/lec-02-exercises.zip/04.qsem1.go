package main

import "fmt"
import "container/list"
import "time"

type Mutex (chan int)

func newMutex() Mutex {
	var ch = make(chan int, 1)
	return ch
}

func lock(m Mutex) {
	m <- 1
}

func unlock(m Mutex) {
	<-m
}

// A first attempt.

/*
func newQSem(q int) QSem {
	var m = newMutex()
	qsem := QSem{q, q, m}

	return qsem
}

func wait(qsem *QSem) {
	lock(qsem.m)
	qsem.curr--
	unlock(qsem.m)
}

func signal(qsem *QSem) {
	lock(qsem.m)
	qsem.curr++
	unlock(qsem.m)
}
*/

/*
* Function `wait` decrements and function `signal` increments the actual quantity.
  Access to `qsem.curr` is protected by a mutex.
* Note: `QSem` will be passed as a pointer, such that its increase/decrease is also visible to the outside.

The above is surely a partial solution.
E.g., in `wait` the value of `qsem.curr` should only be decreased when the value is larger than zero.

What should happen when `qsem.curr` is zero?
Then `wait` should block until a `signal` increases `qsem.curr` to larger than zero again.

What should happen when there are multiple blocking `wait`s?
Then a `signal` should unblock the longest waiting `wait` (guaranteed ``fairness'').
Note that at any point, only one blocked `wait` should be unblocked.

The analogous holds for `signal`.
*/

// Further refinement.

/*
func wait(qsem *QSem) {
	lock(qsem.m)
	if qsem.curr > 0 {
	  	qsem.curr--
		// check for any blocked signal call
	   	// if any, pick the 'first' and unblock
	   	unlock(qsem.m)
	} else {
	  	// wait until unblocked by signal call
	}
}

func signal(qsem *QSem) {
	lock(qsem.m)
	if qsem.curr < qsem.q {
		qsem.curr++
		// check for any blocked wait call
		// if any, pick the 'first' and unblock
		unlock(qsem.m)
	} else {
		// wait until unblocked by wait call
	}
}
*/

/*
How do we manage blocked `wait`s/`signal`s?
The best we can do is to use a dynamic waiting list, used as a queue (see ``fairness'').

How do we inform blocked `wait`s/`signal`s that they can continue?
Through mutexes.
A blocked `wait`/`signal` executes `unlock`.
The thread that lets the blocked thread continue executes `lock'.
*/

// Waiting list for blocked `wait`s/`signal`s; here the final framework.

type QSem struct {
	q              int
	curr           int
	m              Mutex
	blockedWaits   *list.List
	blockedSignals *list.List
}

func newQSem(q int) QSem {
	var m = newMutex()
	qsem := QSem{q, q, m, list.New(), list.New()}

	return qsem
}

func wait(qsem *QSem) {
	lock(qsem.m)
	if qsem.curr > 0 {
		if qsem.blockedSignals.Len() > 0 {
			var s = qsem.blockedSignals.Front()
			qsem.blockedSignals.Remove(s)
			unlock(qsem.m)
			lock(s.Value.(Mutex)) // signal blocked signal thread
		} else {
			qsem.curr-- // we won't decrement if wait unblocks a signal
			unlock(qsem.m)
		}
	} else {
		var w = newMutex()
		qsem.blockedWaits.PushBack(w)
		unlock(qsem.m)
		unlock(w) // wait for signal on w
	}
}

func signal(qsem *QSem) {
	lock(qsem.m)
	if qsem.curr < qsem.q {
		if qsem.blockedWaits.Len() > 0 {
			var w = qsem.blockedWaits.Front()
			qsem.blockedWaits.Remove(w)
			unlock(qsem.m)
			lock(w.Value.(Mutex)) // signal blocked wait thread
		} else {
			qsem.curr++ // we won't decrement if signal unblocks a wait
			unlock(qsem.m)
		}
	} else {
		var s = newMutex()
		qsem.blockedSignals.PushBack(s)
		unlock(qsem.m)
		unlock(s) // wait for signal on s
	}
}

/*
Note that lists in Go are ``heterogeneous''.
That is, when you take an element from the list, you need to cast its type explicitly.

   var s = qsem.blockedSignals.Front()
   qsem.blockedSignals.Remove(s)
   lock(s.Value.(Mutex))

The above code fragment takes the first element from the list and removes it.
Since we expect the list elements to be mutexes, we cast to `s.Value.(Mutex)`; the call unlocks a blocked `signal`.
*/

func waiter(qsem *QSem, n int) {
	for {
		fmt.Printf("waiter %d waiting\n",n)
		wait(qsem)
		fmt.Printf("waiter %d done\n",n)
		time.Sleep(2e9)
	}
}

func signaler(qsem *QSem, n int) {
	for {
		fmt.Printf("signaler %d signaling\n",n)
		signal(qsem)
		fmt.Printf("signaler %d done\n",n)
		time.Sleep(1e9)
	}
}

func main() {
	var qsem = newQSem(2)
	go waiter(&qsem,1)
	go waiter(&qsem,2)
	go signaler(&qsem,1)
	signaler(&qsem,2)
}