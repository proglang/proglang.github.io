package main

import (
	"fmt"
	"time"
	"math/rand"
)

// Barber shall wait for either a group of blonds or reds.
// The quantities for each group are defined by the following constants.
const BLONDS = 2
const REDS = 3

func barber(blond chan int, red chan int) {
    seenBlonds := 0
    seenReds := 0
    for {
        // Check if group has been formed.
        if seenReds == REDS {
            fmt.Printf("Cutting reds!\n")
            seenReds = 0
        }

        if seenBlonds == BLONDS {
            fmt.Printf("Cutting blonds!\n")
            seenBlonds = 0
        }

        // Check for blonds and reds wanting to join group.
        select {
        case <-blond:
            seenBlonds++
        case <-red:
            seenReds++
        }
    }
}

// Another attempt.
// Any issues?
func barber2(b chan int, r chan int) {
	for {
		select {
		case <-b:
			select {
			case <-b:
				fmt.Println("Working on 2 blond hair customers")
			default:
				b <- 1
				fmt.Println("blond released")
			}
		case <-r:
			select {
			case <-r:
				select {
				case <-r:
					time.Sleep(100 * time.Millisecond)
					fmt.Println("Working on 3 red hair customers")
				default:
					r <- 1
					r <- 1
					fmt.Println("reds released")
				}
			default:
				r <- 1
				fmt.Println("red released")
			}
		}
	}
}

func customerSimulation(ch chan int, t string) {
    x := 0
    for {
        rand.Seed(time.Now().UnixNano())
        n := rand.Intn(4) // n will be between 0 and 4
        time.Sleep(time.Duration(n) * time.Second)
		fmt.Printf("%s arrived\n",t)
        x++
        ch <- x
    }
}

func testBarber() {
    blond := make(chan int)
    red := make(chan int)

    go customerSimulation(blond, "blond")
    go customerSimulation(red, "red")

    barber(blond, red)
}

func testBarber2() {
    blond := make(chan int)
    red := make(chan int)

    go customerSimulation(blond, "blond")
    go customerSimulation(red, "red")

    barber2(blond, red)
}

func testBarber2b() {
    blond := make(chan int, 2)
    red := make(chan int, 3)

    go customerSimulation(blond, "blond")
    go customerSimulation(red, "red")

    barber2(blond, red)
}

func main() {
    testBarber2b()
}

// Issue 1:
// barber2 checks for two blonds,
// if say there is no second blond available, the first blond is released.
// See the following code fragment.
//         select {
//         case <-b:
//             select {
//             case <-b:
//                 fmt.Println("Working on 2 blond hair customers")
//             default:
//                 b <- 1
//             }
// What's the issue?
// Assuming we use unbuffered channels, the barber himself cannot directly release the blond, because we then run into a deadlock.
// Below is a sample execution run represented as a trace of events.
// We make use of the following notation.
//
//  BLOND  = customerSimulation for blonds thread
//  RED    = customerSimulation for reds thread
//  BARBER = barber thread
//
//  Events:
//      b? receive via blond channel
//      b! send via blond channel
//
//      b! is a blocking event in case of unbuffered channels
//
//  The trace represents the interleaved execution of the program.
//  We consider the following specific execution run where we use a tabular notation to represent the trace.
//
//  We write b!_1 to denote the send event at trace position 1 and so on.
//
//      BLOND    RED     BARBER
//
//  1.    b!
//  2.                    b?  sync with b!_1
//  3.           r!
//  4.                    b!
//  5.    b!
//
//     At trace position 4 we find b! because
//     the barber has only encountered a single blond,
//     so attempts to put the first received blond.
//     BARBER blocks (no matching b?).
//     RED block (no matching r?).
//     BLOND continues but also blocks (no matching b?)

// Fix for issue 1:
// Either (a) use helper threads to put back the released blonds and red, or
// (b) use buffered channels.
// Any remaining issues?
// A livelock is possible.
// Consider the following execution run.
//
//   BLOND     RED      BARBER
//    b!
//                       b?
//                       b!  release
//                       b?
//                       b!  release
//                       ...
//
//  Assuming there is some progress guarantee where
//  (a) each thread will not have to wait indefinitely *and*
//  (b) the default case only applies if no other cases are applicable,
/// then a livelock can be avoided.