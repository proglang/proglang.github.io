// Alternative Implementation of the Quantified Semaphor

/*
The list of "blocked" `wait`s and `signal`s models a queue.
Internally, Go uses such queues for blocked senders/recipients of synchronous channels.
Hence, a shorter and more direct implementation of the quantified semaphor is as follows.

type QSem struct {
     q              int
     curr           int
     m              Mutex
     signalWaits    Mutex
     signalSignals  Mutex
     noBlockedWaits int
     noBlockedSignals int
}

A blocked `signal` waits for `signalSignals`.
A `wait` checks whether there are blocked `signal`s.
And vice versa.

Note that, since neither of `wait` and `signal` blocks simultaneously, a single `signal` could be sufficient.
*/

package main

import "fmt"
import "time"

type Mutex (chan int)

func newMutex() Mutex {
	var ch = make(chan int, 1)
	return ch
}

func lock(m Mutex) {
	m <- 1
}

func unlock(m Mutex) {
	<-m
}

type QSem struct {
	q              int
	curr           int
	m              Mutex
	signalWaits    Mutex
	signalSignals  Mutex
	noBlockedWaits int
	noBlockedSignals int
}

func newQSem(q int) QSem {
	var m = newMutex()
	qsem := QSem{q, q, m, newMutex(), newMutex(), 0, 0}

	return qsem
}

func wait(qsem *QSem) {
	lock(qsem.m)
	if qsem.curr > 0 {
		if qsem.noBlockedSignals > 0 {
			qsem.noBlockedSignals--
			unlock(qsem.m)
			lock(qsem.signalSignals) // signal blocked signal thread
		} else {
			qsem.curr--
			unlock(qsem.m)
		}
	} else {
		qsem.noBlockedWaits++
		unlock(qsem.m)
		unlock(qsem.signalWaits) // wait for signal
	}
}

func signal(qsem *QSem) {
	lock(qsem.m)
	if qsem.curr < qsem.q {
		if qsem.noBlockedWaits > 0 {
			qsem.noBlockedWaits--
			unlock(qsem.m)
			lock(qsem.signalWaits) // signal blocked wait thread
		} else {
			qsem.curr++
			unlock(qsem.m)
		}
	} else {
		qsem.noBlockedSignals++
		unlock(qsem.m)
		unlock(qsem.signalSignals) // wait for signal
	}
}

func waiter(qsem *QSem, n int) {
	for {
		fmt.Printf("waiter %d waiting\n",n)
		wait(qsem)
		fmt.Printf("waiter %d done\n",n)
		time.Sleep(2e9)
	}
}

func signaler(qsem *QSem, n int) {
	for {
		fmt.Printf("signaler %d signaling\n",n)
		signal(qsem)
		fmt.Printf("signaler %d done\n",n)
		time.Sleep(1e9)
	}
}

func main() {
	var qsem = newQSem(2)
	go waiter(&qsem,1)
	go waiter(&qsem,2)
	go signaler(&qsem,1)
	signaler(&qsem,2)
}

/*
# Compare both solutions.

The first solution with the explicit queue seems unnecessarily complicated (at least we get to see an example of a list in Go).
What could be the benefit of the solution over the second solution?

## Utilisation of concurrency

Concurrency concepts (thread, channels, ...) serve to structure complex problems, where parts run individually (concurrently) from each other.

One side-effect of concurrent programming, is that, given the right hardware (e.g., multicore), concurrent program parts can run in parallel on different cores.

Based on the implementation of the quantified semaphor, which parts can be run in parallel?

In the first solution, every blocked thread waits for its own signal.
Hence, it is possible that multiple threads can be "restarted" simultaneously.
In the second solution, "restart" signals are handled sequentially.

Note that of course the bottleneck is access to the queue, which also in the first solution happens sequentially.
However, the "restart" signals can be sent simultaneously.

As a further increase of the concurrency of the first solution, we can send "restart" signals in separate threads.

func wait(qsem *QSem) {
	...
	unlock(qsem.m)
	go lock(s.Value.(Mutex)) // signal blocked signal thread
	...
}

As a consequence, the main thread can continue with its work in the meantime.

Note that, since Google Go (partially) uses cooperative scheduling, it could be that the theoretically high amount of concurrency cannot be used in practice (as in, running threads in parallel).
*/