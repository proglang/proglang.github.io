// publish, subscribe example, adopted from Russ Cox

package main

import "fmt"
import "time"
import "strconv"
import "container/list"

/*
In the following, we incrementally develop a solution.
Firstly, a few necessary data structures.
*/

// Every message consists of a "topic" and a "body".
type Message struct {
	topic string
	body  string
}

// Every subscriber registers a "topic" and a "news" channel along which messages on the corresponding "topic" can be received.
type Sub struct {
	topic string
	news  chan Message
}

// The server holds two channels: csub on which subscribers can register, and cpub along which a published sends messages. 
type Server struct {
	csub chan Sub
	cpub chan Message
}

// Subscriber and Publisher

// A subscriber registers and waits for messages.
func subscriber(server Server, t string) {
	s := Sub{topic: t, news: make(chan Message)}
	server.csub <- s

	for {
		msg := <-s.news
		fmt.Printf("topic %s: \n message %s \n", t, msg.body)
	}
}

// A publisher (here, "slashdot") sends messages along the corresponding channel.
func slashdot(server Server) {
	for {
		m := Message{topic: "slashdot", body: "some news"}
		server.cpub <- m
		time.Sleep(2 * 1e9)
	}
}

/*
The server manages the subscriber list.
At the same time (via `select`), it listens for subscribers and publishers.
A subscriber is simply added to the list.
A messages from a publisher is sent to the corresponding subscribers.
*/
func pubSubServer(server Server) {
	subscribers := list.New()

	for {
		select {
		case s := <-server.csub:
			subscribers.PushBack(s)
		case m := <-server.cpub:
			for e := subscribers.Front(); e != nil; e = e.Next() {
				s := (e.Value).(Sub) // type assertion
				if s.topic == m.topic {
					s.news <- m // (B)
				}
			}
		}
	}
}

/* Blocking of the server.

Now, for the question in the exercise: if the server manages all clients in one thread, the server can block when Subscribe clients stop reading messages.
Why?

Consider the line marked (B).
When a subscriber doesn't receive the message, the server will block on this line.
What could alleviate the problem?
1. The "news" channels of the subscribers have a buffer.
   What if the buffer is full?
2. We give each subscriber their own thread.
   This thread handles all the messages meant for the corresponding subscriber.
   In other words, we don't send the message directly to the subscriber, but first to the helper thread.
   This helper thread guarantees that all messages are handled and of course cannot block.
   When the buffer is full, one can
   (a) discard messages, or
   (b) use an internal, dynamic buffer.
3. There is another possiblity.
   Replace line (B) by
   `go func() { s.news <- m }()`
   Publishing the message happens asynchronously.
   This way, we effectively model a channel with infinite buffer size (only limited by RAM).
*/

func reuters(server Server) {
	i := 0
	for {
		s := strconv.Itoa(i)
		m := Message{topic: "reuters", body: "some news " + s}
		server.cpub <- m
		time.Sleep(1 * 1e9)
		i++
	}
}

func main() {
	server := Server{csub: make(chan Sub), cpub: make(chan Message)}

	go pubSubServer(server)
	go subscriber(server, "slashdot")
	go subscriber(server, "reuters")

	go slashdot(server)
	reuters(server)
}