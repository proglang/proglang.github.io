RED       = "\033[0;31m"
GREEN     = "\033[0;32m"
BLUE      = "\033[0;34m"
PURPLE    = "\033[0;35m"
CYAN      = "\033[0;36m"
GRAY      = "\033[0;37m"
DARK_GRAY = "\033[1;30m"
RESET     = "\033[0m"

def report(file: str, src: str, title: str, span: tuple[int, int], message: str):
    (begin, end) = span
    row = 0
    col = 0
    line = ""
    lines = []
    begin_row = None
    begin_col = None
    end_row = None
    end_col = None
    for i, c in enumerate(src):
        if i == begin:
            begin_row = row
            begin_col = col
        if i == end:
            end_row = row
            end_col = col
        if c == '\n':
            row += 1
            col = 0
            if i > begin:
                lines.append(line)
            if i >= end:
                break
            line = ""
        else:
            line += c
            col += 1

    if begin_row is None or begin_col is None or end_row is None or end_col is None:
        raise Exception("Invalid span in error reporting")

    lines[-1] = lines[-1][:end_col] + RESET + lines[-1][end_col:]
    lines[0] = lines[0][:begin_col] + BLUE + lines[0][begin_col:]

    print(f"{RED}Error:{RESET} {title}")
    print(f"    [{file}:{begin_row+1}:{begin_col+1}]")
    print()
    for i, l in enumerate(lines):
        print(f"{begin_row + i + 1}\t{l}")
    print()
    print(f"    {BLUE}{message}{RESET}")
