## Example for constant propagation

```
 1 z = 3              | z=3           |
 2 x = 1              | z=3, x=1      |
 3 while (x > 0) {    |               | z=3, x=T, y=7
 4   if (x = 1) then  | z=3, x=1      | z=3, x=1, y=7
 5     y = 7          | z=3, x=1, y=7 | z=3, x=1, y=7
 6   else             |
 7     y = z + 4      |               | z=3, x=T, y=7
                      | z=3, x=1, y=7 | z=3, x=T, y=7
 8   x = 3            | z=3, x=3, y=7 | z=3, x=3, y=7
 9   print y          |
10 }   
```

## expectations

* z=3 is a constant throughout
* x is not a constant at the beginning of the while loop (line 4)
* x=1 at line 5
* y=7 in the while loop





















## Example for CSE


```
L1:                        | {}
  x ← a ⊕ b                | { (x, a ⊕ b) }
  if a < b then L2 else L3
L2:
  y ← a ⊕ b                | { (x, a ⊕ b), (y, a ⊕ b) }
  goto L4(y)
L3:
  z ← x ⊕ b                | { (x, a ⊕ b), (z, x ⊕ b) }
  goto L4(z)
L4(w):                     |   { (x, a ⊕ b), (w, a ⊕ b) } /\ { (x, a ⊕ b), (w, x ⊕ b) }
                           | = { (x, a ⊕ b) }
  u ← a ⊕ b
```
