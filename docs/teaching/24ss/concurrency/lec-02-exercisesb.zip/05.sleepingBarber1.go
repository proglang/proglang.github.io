// Second 'barber' thread.

func main() {
	var waitQ = make(chan Request, NUMBER_OF_CHAIRS)

	go customer(waitQ, 1)
	go customer(waitQ, 2)
	go barber(waitQ)
	barber(waitQ)
}

/*
Channel `waitQ` is the bottleneck.

Idea: designated channel per barber.
Choice of barber through a `select`.
Prioritisation possible.
*/