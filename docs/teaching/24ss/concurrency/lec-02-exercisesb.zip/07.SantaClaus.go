/*
*Plan of attack*

* Our goal is to encode the santa claus problem in GoLang

* Next, we will incrementally develop the various solution parts.
  The complete solution can be found at the end.

## Channels to represent elves and deer

Elves and deer are represented as channels with the appropriate buffer size.

	deer := make(chan int, 9)
	elves := make(chan int, 10)

Initially, all elves and deer are available, i.e. released from any of their duties.

	release(deer, 9)
	release(elves, 10)

The helper function `release` simply fills the buffer with a dummy element for each released deer and elf.

func release(ch chan int, num int) {
	for i := 0; i < num; i++ {
		ch <- 1
	}
}

## Checking for a waiting group of elves and deer

The task of santa is to check for a waiting group of deer and elves.
That is, to check if there are enough released deer and elves.

func santa(deer chan int, elves chan int) {
	numOfDeerSeen := 0
	numOfElvesSeen := 0

The idea is to count the number of elves and deer by querying the respective channel.

	for {
		select {
		case <-deer:
			numOfDeerSeen++
		default:
			select {
			case <-elves:
				numOfElvesSeen++
			default:
			}

		}

The `select` statement allows us to check if there is any deer or elf available.
If there's none, we simply wait.

		if numOfDeerSeen == 9 {
			fmt.Print("Deliver toys \n")
			time.Sleep(1 * 1e9)
			numOfDeerSeen = 0
			release(deer, 9)
		}

		if numOfElvesSeen == 3 {
			fmt.Print("R&D \n")
			time.Sleep(1 * 1e9)
			numOfElvesSeen = 0
			release(elves, 3)
		}
	}
}

Then, we check if we have a large enough group assembled.
Either three elves or nine deer.
If yes, we perform the respective task and after they served their duty, we release them again.

This activity of checking for deer and elves and testing if we have assembled a group runs in an infinite loop.

## Santa shall give priority to a group of deer

What about the priority rule?

Santa gives priority to the reindeer in the case that there is both a group of elves and a group of reindeer waiting.

Let's run some tests.

> R&D
> R&D
> Deliver toys
> R&D
> R&D
> R&D
> Deliver toys
> R&D
> R&D
> R&D
> R&D
> Deliver toys
> R&D
> R&D
> R&D

It seems that we're more likely to perform R&D than delivering of toys, even in case there's a group of nine deer waiting.

But don't we favor deer in the `select` statement?
Recall

		select {
		case <-deer:
			numOfDeerSeen++
		case <-elves:
			numOfElvesSeen++
		}

It seems that we first check for a waiting deer by performing a receive over the `deer` channel.
If there's a deer available (in the `deer` channel buffer), then the receive statement will unblock.
We say that the event (here receive) takes place.
However, the above textual order is misleading.

In case several events can take place, here either a waiting deer or elf, one of the events will be chosen *non-deterministically*.
The choice does not depend on the textual order!

Hence, it is entirely possible that there's a waiting deer *and* a waiting elf but we will favor the elf.
So, what can we do to favor deer?

## Give priority to a group of waiting deer

Thankfully, the `select` statement supports a `default` case which will be chosen if all other cases are blocked (that is, no event takes place at the moment).
We can make use of `default` as follows.

		select {
		case <-deer:
			numOfDeerSeen++
		case <-elves:
			numOfElvesSeen++

			select {
			case <-deer:
				numOfDeerSeen++
			default:
			}
		}

If we favor an elf, we immediately check (nested `select`) if there's also a waiting deer.
If there's none, we will choose the `default` case.
Thus, we give priority to the reindeer in the case that there is both a group of elves and a group of reindeer waiting.

Here's a sample run for the above variant.
As we can seen, delivering toys now takes place more frequently.

> R&D
> Deliver toys
> Deliver toys
> R&D
> R&D
> R&D
> Deliver toys
> R&D
> R&D
> Deliver toys
> R&D
> R&D
> Deliver toys
> R&D
> Deliver toys
> R&D
> R&D
> Deliver toys
> R&D
> Deliver toys

## Alternatives

Consider the following variant

		select {
		case <-deer:
			numOfDeerSeen++
		case <-elves:
			select {
			case <-deer:
				numOfDeerSeen++
				go func() { elves <- 1 }()
			default:
				numOfElvesSeen++
			}
		}

* Release an elf if we find a deer as well.
* Has the advantage that the order of the `if` statements does not matter.
* On the other hand, the order in which elves arrive is destroyed, by putting the elf we have seen back into the channel (queue).

Here's yet another alternative.

		select {
		case <-deer:
			numOfDeerSeen++
		default :
			select {
			case <-deer:
				numOfDeerSeen++
			default:
			}
		}

* The disadvantage of this version is that we effectively encode a busy-waiting loop.
   	For example, consider the case if neither a deer nor an elf is available.

## Further challenges and improvements

In our current solution

* assembling a group,
* checking for a sufficiently large group, and
* performing the respective task

is done sequentially.

That is, while santa performs a certain task with a group, the other group is blocked.
It's more realistic that meanwhile the other group continues.

For example, consider the following scenario:

* A group of nine deer assembles
* Santa awakes and delivers toys
* Meanwhile a group of three elves assembles
* Santa comes back and immediately picks the group of three waiting elves because the deer are still doing something else

Your (challenging) task is to

* allow that a group can concurrently assemble,
* while another group is performing a certain task with santa.

## Some runnable code

Santa with and without enforcing the priority rule.
None of the improvements are yet incorporated.
*/

package main

import "fmt"
import "time"

// Release by sending a (dummy) value.
func release(ch chan int, num int) {
	for i := 0; i < num; i++ {
		ch <- 1
	}
}

// Check for a group of waiting deer or elves.
// Select the first available group
// N.B. The priority rule is not enforced here.
func santa(deer chan int, elves chan int) {
	numOfDeerSeen := 0
	numOfElvesSeen := 0

	for {
		select {
		case <-deer:
			numOfDeerSeen++
		case <-elves:
			numOfElvesSeen++
		}

		if numOfDeerSeen == 9 {
			fmt.Print("Deliver toys \n")
			time.Sleep(1 * 1e9)
			numOfDeerSeen = 0
			release(deer, 9)
		}

		if numOfElvesSeen == 3 {
			fmt.Print("R&D \n")
			time.Sleep(1 * 1e9)
			numOfElvesSeen = 0
			release(elves, 3)
		}
	}
}

// Giving priorities to deer
func santaPrio(deer chan int, elves chan int) {
	numOfDeerSeen := 0
	numOfElvesSeen := 0

	for {
		select {
		case <-deer:
			numOfDeerSeen++
		case <-elves:
			numOfElvesSeen++

			select {
			case <-deer:
				numOfDeerSeen++
			default:
			}
		}

		if numOfDeerSeen == 9 {
			fmt.Print("Deliver toys \n")
			time.Sleep(1 * 1e9)
			numOfDeerSeen = 0
			release(deer, 9)
		}

		if numOfElvesSeen == 3 {
			fmt.Print("R&D \n")
			time.Sleep(1 * 1e9)
			numOfElvesSeen = 0
			release(elves, 3)
		}
	}
}

func main() {
	deer := make(chan int, 9)
	elves := make(chan int, 10)
	release(deer, 9)
	release(elves, 10)
	santa(deer, elves)
	// santaPrio(deer, elves)
	fmt.Print("done \n")

}